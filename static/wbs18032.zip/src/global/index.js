import VueAwesomeSwiper from 'vue-awesome-swiper'

export default {
    install:function(Vue){
        Vue.use(VueAwesomeSwiper);
    }
}