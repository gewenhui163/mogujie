import Vue from 'vue';
// import Vuex from 'vuex'
import App from './App';

import store from './store';

import router from './router';
import global from './global'

// 在构建项目时  装载插件
import 'lib-flexible';

Vue.config.productionTip = false

Vue.use(global);

// 1. 装载Vuex 功能
// Vue.use(Vuex);

// 2. 构建Vuex 仓库对象
// new Vuex.Store(options)
//  options:传入 数据的初始值（state） 
//          传入 数据突变方法 (mutations)
//          传入 数据 ajax 请求接口 （actions）
// const store = new Vuex.Store({
//   state:{
//     msg:"测试数据",
//     num:100,
//     arr:[1,2,3,4],
//     user:{
//       name:"tom",
//       age:23
//     }
//   },
//   actions:{
//     // action 定义的方法 第一个参数 是固定的 vuex仓库对象参数
//     //    后续的参数 为该方法调用时 传入的 额外参数
//     changeArr({ commit },data){
//       // console.log(s,data);
//       // 模拟远端数据加载
//       let newArr = ["a","b","c"];
//       commit("setArr",newArr);

//     }
//   },
//   mutations:{
//     // 突变方法定义时，第一个参数为 固定值 vuex state 对象
//     // 后续参数为 传入数据
//     setMsg(state,data){
//       state.msg = data;
//     },
//     setArr(state,data){
//       state.arr = data;
//     }
//   }
// });

new Vue({
  el: '#app',
  router,
  // 3. 在root对象中 注入 vuex实例
  store,
  components: { App },
  template: '<App/>'
})
