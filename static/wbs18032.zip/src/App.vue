<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
/* 全局样式 */
*:not(.swiper-wrapper){
  padding: 0px;
  margin: 0px;
  overflow: hidden;
}
.swiper-pagination-bullet {
  width: 18px;/*px*/
  height: 18px;/*px*/
  display: inline-block;
  border-radius: 100%;
  background: white;
  opacity: 0.8;
}
.swiper-pagination-bullet-active {
  opacity: 1;
  background: #007aff;
}
#app{
  position: absolute;
  top: 0px;
  left: 0px;
  right: 0px;
  bottom: 0px;
}
</style>
