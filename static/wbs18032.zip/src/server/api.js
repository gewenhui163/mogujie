import jsonpUtil  from '../util/jsonpUtil';

// 对于远端数据的加载
// 常量应该是一个统一的数据服务地址
const mce = "https://mce.mogucdn.com/jsonp/";

export default {
    // 数据的具体请求方法

    /**
     * 根据参数 pids 查询 相关数据
     * @param pids:string
     */
    loadDatasByPids(params){
        let url = mce+"multiget/3";
        return jsonpUtil.request(url,params);;
    }

    



}
