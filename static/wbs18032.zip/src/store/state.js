export default {
    msg:"测试",
    arr:[1,2,3,4]
}