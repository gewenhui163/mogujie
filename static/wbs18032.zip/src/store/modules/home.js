import api from '../../server/api';

const state = {
    warpImgs:[],
    types:[],
    bebefit:[],
    hotType:[],
    likes:[]
}

const getters = {

}

const actions = {
    loadHomeData({ commit }){
        api.loadDatasByPids({
            appPlat: "m",
            pids: "51822,106930,51833,51836"
        }).then(({ data })=>{
            commit("setWarpImgs",data[51822].list);
            commit("setTypes",data[106930].list);
            commit("setBebefit",data[51833].list);
            commit("setHotType",data[51836].list);
        })
    },
    // loadLikes
}

const mutations = {
    setWarpImgs(state,data){
        state.warpImgs = data;
    },
    setTypes(state,data){
        state.types = data;
    },
    setBebefit(state,data){
        state.bebefit = data;
    },
    setHotType(state,data){
        state.hotType = data;
    },
    setLikes(state,data){
        state.likes = data;
    }
}



export default {
    state,
    actions,
    getters,
    mutations
}