export default {
    changeArr({ commit },data){
        // 模拟数据加载
        let newArr = ["a","b","c"];
        commit("setArr",newArr);
    }
}