export default {
    getMsg(state){
        return state.msg + "-新加的字符串";
    }
}