export default {
    setMsg(state,data){
        state.msg = data;
    },
    setArr(state,data){
        state.arr = data;
    }
}