<template>
    <div class="home">
        <div class="nav">导航</div>

        <div class="body">
            <div class="wrapper" ref="helloWorld">
                <div class="content">

                    <!-- 轮播 -->
                    <div class="warp">
                        <!-- <div class="swiper-wrapper">
                            <div class="swiper-slide">slider1</div>
                            <div class="swiper-slide">slider2</div>
                            <div class="swiper-slide">slider3</div>
                        </div> -->
                        <swiper :options="swiperOptions">
                            <swiper-slide v-for="(v,i) of home.warpImgs" :key="'warp'+i">
                                <img :src="v.image_800" alt="" srcset="">
                            </swiper-slide>
                            <!-- <swiper-slide>
                                <img src="/static/img/2.webp" alt="" srcset="">
                            </swiper-slide>
                             <swiper-slide>
                                <img src="/static/img/3.webp" alt="" srcset="">
                            </swiper-slide> -->

                            <div class="swiper-pagination" slot="pagination"></div>

                        </swiper>

                    </div>

                    <div class="aa" v-for="(v,i) of 30" :key="i">
                        asdasd
                    </div>
                </div>
            </div>
        </div>

        <div class="foot">底部</div>
    </div>

</template>

<script>
// 加载 import BScroll from 'better-scroll'
import BScroll from "better-scroll";
import { swiper, swiperSlide } from "vue-awesome-swiper";

// 装载 vuex 辅助函数 简化组件开发
import {mapState,mapMutations,mapActions,mapGetters} from "vuex";

export default {
    components: {
        swiper,
        swiperSlide,
        pagination: ".swiper-pagination"
    },
    data() {
        return {
            swiperOptions: {
                autoplay: 2000,
                loop: true,
                pagination: ".swiper-pagination",
                paginationClickable: true
            }
        };
    },
    computed:{
        // 对象展开符号
        ...mapState(['home']),
        // "home.warpImgs":function() {
        //     return this.$store.state.home.warpImgs;
        // }
    },
    methods: {
        initScroll() {
            this.$nextTick(() => {
                // new Bscroll(被滚轮化的DOM元素, 滚动条的配置参数)
                this.scroll = new BScroll(this.$refs.helloWorld, {});
            });
        },
        ...mapActions(["loadHomeData"])
        // loadHomeData(){

        // }
    },
    mounted() {
       this.loadHomeData();
    }
};
</script>

<style lang="less" scoped>
/* 
    css model
    组件名缩写-容器名-子样式 hw-navbar-title
  */
.home {
    height: 100%;
}
.nav {
    height: 80px; /*px*/
    background-color: #ccc;
}
.body {
    position: absolute;
    top: 80px; /*px*/
    bottom: 80px; /*px*/
    left: 0px;
    right: 0px;
}
.wrapper {
    width: 100%;
    height: 100%;
}
.aa {
    // height: 40px;
    // width: 100px;
    border: 1px solid #cccccc;
    font-size: 60px; /*px*/
}
.foot {
    position: fixed;
    bottom: 0px;
    width: 100%;
    background-color: #ccc;
    height: 80px; /*px*/
}

.warp {
    width: 100%;
    height: auto;
    img {
        width: 100%;
        height: auto;
    }
    .swiper-pagination {
        background-color: rgba(51, 51, 51, 0.4);
    }
}
</style>