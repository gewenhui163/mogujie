<template>
    <div>
        <h1>vuex</h1>
        <hr>
        <h3>{{ msg }}</h3>
        <input type="text" v-model="msg">
        <hr>
        <h3>{{ info }}</h3>
        <input type="text" v-model="info">
        <hr>
        <h3>{{ arr }}</h3>
        <input type="button" value="远端获取数据" @click="loadArr()">
        <hr>
        <h3>{{ message }}</h3>
    </div>
</template>

<script>
export default {
    data(){
        return {
            msg:this.$store.state.msg
        }
    },
    computed:{
        info:{
            get(){
                return this.$store.state.msg;
            },
            set(newStr){
                // this.$store.commit(突变方法名,新值)
                this.$store.commit("setMsg",newStr);
            }
        },
        arr(){
            return this.$store.state.arr;
        },
        message(){
            console.log(this.$store)
            return this.$store.getters.getMsg;
        }
    },
    methods:{
        loadArr(){
            // console.log(this.$store);
            // dispatch:ƒ boundDispatch(type, payload)
            //      type action方法名
            //      payload  额外的数据参数
            this.$store.dispatch("changeArr","ssss");
        }
    },
    mounted(){
        console.log(this.$store.state.msg);
    }
}
</script>